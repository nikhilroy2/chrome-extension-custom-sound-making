
// console.log("extension log")
// let nikhilScript = document.createElement('script')
// nikhilScript.src = chrome.runtime.getURL('soundCdn.js')
// nikhilScript.async = false;

// document.documentElement.appendChild(nikhilScript)

